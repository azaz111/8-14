from google.oauth2 import service_account
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
import io
from googleapiclient.errors import HttpError
import os , math
from sys import argv
import json
import subprocess
from BIB_API import service_avtoriz , perenos_fails_list , spisok_fails_q ,new_drive , \
           spisok_fails_roditelya,createRemoteFolder,peremesti_v_odnu , drive_ls ,_is_success
successful = []

service = service_avtoriz()
service2 = service_avtoriz('v2')

drive_bibl={}
for qqq in drive_ls(service):
    print(qqq)
    drive_bibl[qqq['name']] = qqq['id'] #Создаем библиотеку дисков

ls_files=[]
ls_d=[]
n=0

while n != 101:
    n+=1
    #print(n)
    try:
       ls_d.append(drive_bibl[str(n)])
    except:
        pass    
print('zapisali : ' + str(len(ls_d)))
ls_d = '\n'.join(ls_d)

with open("/root/AutoRclone/Spisok_drive.txt", "w") as f_out:
   f_out.write(f"{ls_d}")
   
print('zaezd uspeh !')
