from __future__ import print_function
import os.path
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
import os
import subprocess
from sys import argv
import fileinput
from time import sleep
from googleapiclient.errors import HttpError
from BIB_API import service_avtoriz , perenos_fails_list , new_drive ,folder_po_id , nev_json_autoriz
# If modifying these scopes, delete the file token.json.

