from time import time
from google.oauth2.service_account import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from argparse import ArgumentParser
from os.path import exists 
import os 
import time
from json import loads
from glob import glob
import pickle
import subprocess
from sys import argv
from BIB_API import drive_ls, folder_po_id , drive_ls
s_iddrive = argv[1] # НА каком диске
path = 'accounts'

print('НАЧИНАЮ ПОЛНУЮ СМЕНУ НА ДИСКЕ = '+ s_iddrive)

def _get_projects(service):
    return [i['projectId'] for i in service.projects().list().execute()['projects']
            if i.get('lifecycleState', 'ACTIVE') == 'ACTIVE']


token='token.pickle'
if os.path.exists(token):
        with open(token, 'rb') as t:
            creds = pickle.load(t)
cloud = build('cloudresourcemanager', 'v1', credentials=creds)


process = subprocess.Popen(['python3', 'multifactory.py', '--delete-sas', f'{_get_projects(cloud)[1]}'])
process.wait()
process = subprocess.Popen(['python3', 'multifactory.py', '--create-sas', f'{_get_projects(cloud)[1]}'])
process.wait()

try:
   process2 = subprocess.Popen(['python3', 'mas_dell.py','-d', f'{s_iddrive}'])
   process2.wait()
except:
    pass
print('dell vst servis drive')


dirfiles = os.listdir(path)
for w in dirfiles:
    try:
       os.remove(path+'/'+w)
    except OSError as e:
       print("Ошибка: %s : %s")
#
while True:
    try:
        proc=subprocess.Popen(['python3', 'multifactory.py', '--download-keys', f'{_get_projects(cloud)[1]}'])
        proc.wait(timeout=25)
        print('Завершился')
        break
    except subprocess.TimeoutExpired:
        proc.terminate()
        print('Не завершился')
        process = subprocess.Popen(['python3', 'multifactory.py', '--delete-sas', f'{_get_projects(cloud)[1]}'])
        process.wait()
        process = subprocess.Popen(['python3', 'multifactory.py', '--create-sas', f'{_get_projects(cloud)[1]}'])
        process.wait()


i = 1
for filename in os.listdir(path):
    os.rename(os.path.join(path,filename), os.path.join(path,str(i)+'.json'))
    i = i +1 

process = subprocess.Popen(['python3', 'nashare.py','-d', f'{s_iddrive}'])
process.wait()

print('ОК')


#s_iddrive
#
#process = subprocess.Popen(['python3', 'masshare.py', '-d', f'{razn_grive_id}'])
#process.wait()


#python3 multifactory.py --create-sas saf-dhdpbo8qbhsw899h713k6oemby
#python3 masshare.py -d 0AA2UeWDMZoMFUk9PVA
#python3 mas_dell.py -d 0AA2UeWDMZoMFUk9PVA
#python3 multifactory.py --delete-sas saf-g40wa6df1i2wg-grw1mjlvsxw1
#python3 multifactory.py --download-keys saf-nanccq7nihfp7fc1zeyduzg-bh
#python3 multifactory.py --quick-setup 
#python3 multifactory.py --list-projects
#python3 multifactory.py --create-projects 5
#python3 multifactory.py --max-projects
#python3 multifactory.py --delete-sas saf-nanccq7nihfp7fc1zeyduzg-bh

#python3 multifactory.py  --create-sas saf-nanccq7nihfp7fc1zeyduzg-bh


# saf-nanccq7nihfp7fc1zeyduzg-bh


